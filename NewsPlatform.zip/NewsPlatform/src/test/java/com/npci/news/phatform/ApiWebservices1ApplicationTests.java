package com.npci.news.phatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiWebservices1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
