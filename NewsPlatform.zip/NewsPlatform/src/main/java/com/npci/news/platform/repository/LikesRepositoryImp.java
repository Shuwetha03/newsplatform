package com.npci.news.platform.repository;

public class LikesRepositoryImp{

	
	
}
