import { SubCategory } from './sub-category';

describe('SubCategory', () => {
  it('should create an instance', () => {
    expect(new SubCategory()).toBeTruthy();
  });
});
