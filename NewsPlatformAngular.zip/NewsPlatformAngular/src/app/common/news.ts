export class News {

    constructor(public nid:number,
        public comment:string,
        public content:string,
        public sid:number,
        public author:string
        
        ){}
}
