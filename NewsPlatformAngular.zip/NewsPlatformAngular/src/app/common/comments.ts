export class Comments {

    constructor(public commentid:number,
        public comment:string,
        public uid:number,
        public uname: string,
        public aid:number,
        public nid:number,
        ){}
}
