export class Subcategory {

    constructor(public sid:number,
        public cname:string,
        public id:number,
        
        ){}
}
