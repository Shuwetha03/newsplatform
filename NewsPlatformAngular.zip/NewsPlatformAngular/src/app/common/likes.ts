export class Likes {

    constructor(public likeid:number,
        public uid:number,
        public uname:string,
        public nid:number,
        ){}
}
