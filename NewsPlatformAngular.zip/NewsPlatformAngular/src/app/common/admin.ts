export class Admin {

    constructor(public aid:number,
        public aname:string,
        public email:string,
        public password: string
        ){}
}
