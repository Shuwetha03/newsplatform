import { Likes } from './likes';

describe('Likes', () => {
  it('should create an instance', () => {
    expect(new Likes()).toBeTruthy();
  });
});
